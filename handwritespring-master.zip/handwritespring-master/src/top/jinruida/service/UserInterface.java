package top.jinruida.service;

public interface UserInterface {

    public void test();
}
