package top.jinruida.service;

import top.jinruida.spring.Autowired;
import top.jinruida.spring.Component;

@Component
public class OrderService {
//    @Autowired
//    private UserService userService;
//
//    public void test(){
//        System.out.println(userService);
//    }
}
