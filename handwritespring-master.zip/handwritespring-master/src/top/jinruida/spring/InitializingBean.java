package top.jinruida.spring;

public interface InitializingBean {
    public void afterPropertiesSet();
}
