package top.jinruida.spring;

public interface BeanNameAware {

    public void setBeanName(String beanName);
}
